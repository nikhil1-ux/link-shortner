import React, { useState, useRef } from 'react';
import Icon from './components/Icon';

export default function App() {
    const [longUrl, setLongUrl] = useState('');
    const [shortUrl, setShortUrl] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [copySuccess, setCopySuccess] = useState(false);
    const shortUrlRef = useRef(null);

    const handleShortenUrl = async () => {
        setShortUrl('');
        setError(null);
        setCopySuccess(false);

        if (!longUrl || !/^https?:\/\/.+/.test(longUrl)) {
            setError('Please enter a valid URL (e.g., https://example.com)');
            return;
        }

        setIsLoading(true);

        try {
            const apiUrl = \`https://tinyurl.com/api-create.php?url=\${encodeURIComponent(longUrl)}\`;
            const response = await fetch(\`https://api.allorigins.win/raw?url=\${encodeURIComponent(apiUrl)}\`);

            if (!response.ok) {
                throw new Error('Network response was not ok.');
            }

            const data = await response.text();
            
            if (data.includes('Error')) {
                 throw new Error('The provided URL is invalid or could not be processed.');
            }

            setShortUrl(data);

        } catch (err) {
            console.error("API Error:", err);
            setError(err.message || 'Failed to shorten URL. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleCopyToClipboard = () => {
        if (!shortUrl || !shortUrlRef.current) return;

        const textArea = document.createElement("textarea");
        textArea.value = shortUrl;
        textArea.style.position = "fixed";
        textArea.style.left = "-9999px";
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();

        try {
            document.execCommand('copy');
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        } catch (err) {
            console.error('Failed to copy text: ', err);
            setError('Could not copy the link. Please do it manually.');
        }

        document.body.removeChild(textArea);
    };

    return (
        <div className="bg-slate-900 min-h-screen flex items-center justify-center font-sans p-4">
            <div className="w-full max-w-lg mx-auto bg-slate-800 rounded-2xl shadow-2xl shadow-cyan-500/20 p-6 md:p-8 text-white">
                <div className="text-center mb-8">
                    <h1 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-blue-500">Link Shortener</h1>
                    <p className="text-slate-400 mt-2">Create short and shareable links in seconds.</p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3 mb-6">
                    <div className="relative flex-grow">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                           <Icon path="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" className="w-5 h-5 text-slate-500" />
                        </div>
                        <input
                            type="url"
                            placeholder="https://your-long-url.com/goes-here"
                            value={longUrl}
                            onChange={(e) => setLongUrl(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleShortenUrl()}
                            className="w-full bg-slate-700 border-2 border-slate-600 rounded-lg py-3 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:border-cyan-500 transition duration-300"
                        />
                    </div>
                    <button
                        onClick={handleShortenUrl}
                        disabled={isLoading}
                        className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:shadow-cyan-500/50 transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                    >
                        {isLoading ? (
                            <>
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Shortening...
                            </>
                        ) : (
                           <>
                                <Icon path="M9.813 15.904L9 15l.813.904m-2.829-6.813L6 9l.184-.903M14.186 15.904L15 15l-.814.904M12 21a9 9 0 110-18 9 9 0 010 18z" className="w-5 h-5 mr-2" />
                                Shorten Link
                           </>
                        )}
                    </button>
                </div>
                {error && (
                    <div className="bg-red-900/50 border border-red-500 text-red-300 px-4 py-3 rounded-lg relative mb-6" role="alert">
                        <strong className="font-bold">Error: </strong>
                        <span className="block sm:inline">{error}</span>
                    </div>
                )}
                {shortUrl && (
                    <div className="bg-slate-700/50 p-4 rounded-lg animate-fade-in">
                        <p className="text-slate-300 mb-2">Here is your short link:</p>
                        <div className="flex flex-col sm:flex-row items-center gap-3 bg-slate-900/50 p-3 rounded-md">
                            <a 
                                href={shortUrl} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                ref={shortUrlRef}
                                className="flex-grow text-cyan-400 font-mono text-lg truncate hover:underline"
                            >
                                {shortUrl}
                            </a>
                            <button
                                onClick={handleCopyToClipboard}
                                className={\`relative w-full sm:w-auto px-5 py-2 rounded-md text-sm font-semibold transition-colors duration-200 flex items-center justify-center \${copySuccess ? 'bg-green-500 text-white' : 'bg-cyan-600 hover:bg-cyan-500 text-white'}\`}
                            >
                                <Icon path={copySuccess ? "M4.5 12.75l6 6 9-13.5" : "M8.25 7.5V6.108c0-1.135.845-2.098 1.976-2.192.373-.03.748-.03 1.126 0 1.131.094 1.976 1.057 1.976 2.192V7.5m-9 3.75h9v8.25h-9z"} className="w-5 h-5 mr-2" />
                                {copySuccess ? 'Copied!' : 'Copy'}
                            </button>
                        </div>
                    </div>
                )}
            </div>
            <style>{\`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(-10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            \`}</style>
        </div>
    );
}